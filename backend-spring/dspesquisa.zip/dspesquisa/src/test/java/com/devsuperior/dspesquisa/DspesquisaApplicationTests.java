package com.devsuperior.dspesquisa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DspesquisaApplicationTests {

	@Test
	void contextLoads() {
	}

}
